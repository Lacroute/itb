f3 framework helpers directory
===

last updates
=

views.php : added nl2p, toJson

datas.php : added check
